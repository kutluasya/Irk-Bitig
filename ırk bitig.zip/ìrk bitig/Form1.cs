﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ırk_bitig
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

   

        private void Form1_Load(object sender, EventArgs e)
        {
            

        }

        private void label1_Click(object sender, EventArgs e)
        {
                   }

        private void button1_Click(object sender, EventArgs e)
        {
            Random ırk = new Random();
            int ırka = ırk.Next(1, 5);
            int ırkb = ırk.Next(1, 5);
            int ırkc = ırk.Next(1, 5);

            string ırk1 = "deneme";
            string ırk2 = "deneme";
            //ırk a-- picture 1 --1.ırk--
            if (ırka == 1)
            {
                pictureBox1.ImageLocation = "C:\\Users\\canka\\source\\repos\\ırk bitig\\ırk bitig\\bin\\Debug\\pic\\ırk11.png";
            }
            if (ırka == 2)
            {
                pictureBox1.ImageLocation = "C:\\Users\\canka\\source\\repos\\ırk bitig\\ırk bitig\\bin\\Debug\\pic\\ırk22.png";
            }
            if (ırka == 3)
            {
                pictureBox1.ImageLocation = "C:\\Users\\canka\\source\\repos\\ırk bitig\\ırk bitig\\bin\\Debug\\pic\\ırk33.png";
            }
            if (ırka == 4)
            {
                pictureBox1.ImageLocation = "C:\\Users\\canka\\source\\repos\\ırk bitig\\ırk bitig\\bin\\Debug\\pic\\ırk44.png";
            }
            //ırk b-- picture 2 --2.ırk--
            if (ırkb == 1)
            {
                pictureBox2.ImageLocation = "C:\\Users\\canka\\source\\repos\\ırk bitig\\ırk bitig\\bin\\Debug\\pic\\ırk11.png";
            }
            if (ırkb == 2)
            {
                pictureBox2.ImageLocation = "C:\\Users\\canka\\source\\repos\\ırk bitig\\ırk bitig\\bin\\Debug\\pic\\ırk22.png";
            }
            if (ırkb == 3)
            {
                pictureBox2.ImageLocation = "C:\\Users\\canka\\source\\repos\\ırk bitig\\ırk bitig\\bin\\Debug\\pic\\ırk33.png";
            }
            if (ırkb == 4)
            {
                pictureBox2.ImageLocation = "C:\\Users\\canka\\source\\repos\\ırk bitig\\ırk bitig\\bin\\Debug\\pic\\ırk44.png";
            }
            //ırk c-- picture 3 --3.ırk--
            if (ırkc == 1)
            {
                pictureBox3.ImageLocation = "C:\\Users\\canka\\source\\repos\\ırk bitig\\ırk bitig\\bin\\Debug\\pic\\ırk11.png";
            }
            if (ırkc == 2)
            {
                pictureBox3.ImageLocation = "C:\\Users\\canka\\source\\repos\\ırk bitig\\ırk bitig\\bin\\Debug\\pic\\ırk22.png";
            }
            if (ırkc == 3)
            {
                pictureBox3.ImageLocation = "C:\\Users\\canka\\source\\repos\\ırk bitig\\ırk bitig\\bin\\Debug\\pic\\ırk33.png";
            }
            if (ırkc == 4)
            {
                pictureBox3.ImageLocation = "C:\\Users\\canka\\source\\repos\\ırk bitig\\ırk bitig\\bin\\Debug\\pic\\ırk44.png";
            }

            ///////////////////////////////////
            ////////////////////////////////
            ///////////////////////////////
            ///

           

            //ırk write--1. ırk --1-1-1
                if (ırka == 1 && ırkb ==1 && ırkc ==1)
            {
                label3.Text = "Ürüng esri togan kuş men. Çıntan ıgaç üze olurupan mengileyür men. Ança bilingler. Edgü ol.";
                label4.Text = " Ak benekli doğan kuşum ben. Sandal ağacı üzerinde oturarak mutluyum ben. Böyle biliniz. İyidir o.";
            }
            //ırk write--2. ırk --2-2-2
            if (ırka == 2 && ırkb == 2 && ırkc == 2)
            {
                label3.Text = "Tensi men. Yarın keçe altun örgin üze olurupan mengilüyer men. Ança bilingler. Edgü ol.";
                label4.Text = "Göğün oğluyum ben. Gündüz gece altın taht üzerine oturup mutluyum ben. Böyle biliniz. İyidir o.";
            }
            //ırk write--3. ırk --4-4-4
            if (ırka == 4 && ırkb == 4 && ırkc == 4)
            {
                label3.Text = "Ala atlıg yol tengri men. Yarın keçe eşür men. Utru eki yalıg kişi oglın sokuşmiş, kişi korkmiş.\n 'Korkma' timiş. 'Kut birgey men' timiş. Ança bilingler. Edgü ol.";
                label4.Text = "Alaca atlı yol tanrısı ben. Gündüz gece koştururum (atımla) ben. Güleryüzlü iki insanoğluna denk gelmiş,\n insanoğulları korkmuş. 'Korkma' demiş. 'Kut vereceğim ben' demiş. Böyle biliniz. İyidir o.";
            }
            //ırk write--4. ırk --3-3-3
            if (ırka == 3 && ırkb == 3 && ırkc == 3)
            {
                label3.Text = "Altun kanatlıg talım kara kuş men. Tanım tüsi takı tükemezken taluyda yatıpan tapladukumin tutar men,\n sebdükimin yiyür men. Antag küçlüg men. Ança bilingler. Edgü ol.";
                label4.Text = "Altın kanatlı yırtıcı kartalım ben. Tenimin tüyleri büyümemişken, denizde yatarak dilediğimi tutarım ben,\n sevdiğimi yerim ben. Ondan güçlüyüm ben. Böyle biliniz. İyidir o.";
            }
            //ırk write--5. ırk --2-4-2
            if (ırka == 2 && ırkb == 4 && ırkc == 2)
            {
                label3.Text = "Beg er yuntıngaru barmiş. Ak bisi kulunlamis. Altun tuyugluk adgırlık yaragay. Tebesingerü barmiş. \nÜrüng ingeni botulamiş. Altun budlalug bugralık yaragay. Ebingerü barmiş. Üçünç kunçuyı urılanmiş. \nBeglik yaragay tir. Mengilik beg ermiş. Ança bilingler anyıg edgü ol.";
                label4.Text = "Bey atlarına doğru gitmiş. Bakmış ki ak kısrağı yavrulamış. Bu taya altın toynaklı bir aygır olmak \nyaraşır diye düşünmüş. Bey bu kez develerine doğru gitmiş. Bakmış ki beyaz dişi devesi yavrukamış. \nBuna altın burunsaklı buğra olmak yaraşır diye düşünümş. Bey bu kezde \nevine doğru gitmiş. Bakmıl ki üçüncü prensesi bir oğlan doğurmuş. Buna da beylik yaraşır diye düşünmüş, \nder. Anlaşılan mutlu bir beymiş. Öylece Biliniz ki Bu fal çok iyidir.";
            }
            //ırk write--6. ırk --2-2-1
            if (ırka == 2 && ırkb == 2 && ırkc == 1)
            {
                label3.Text = "Adıglı tonguzlı art üze sokuşmiş ermiş. Adıgıng karni yarılmış, tonguzung azıgı sınmiştir. ança biling. \nYablag ol ";
                label4.Text = "Bir ayı ile bir domuz bir dağ geçidinde çarpışmışlar. Ayının karnı yarılmış, domuzun azı dişleri kırılmış der.\n Öyle ki bu fal kötüdür.";
            }
            //ırk write--7. ırk --2-1-2
            if (ırka == 2 && ırkb == 1 && ırkc == 2)
            {
                label3.Text = "Er tekleyü kelir. Edgü söz sab elti kelir tir. Ança bilingler. Edgü ol.";
                label4.Text = "Erkek koşarak gelir. İyi söz getirerek gelir. Böyle biliniz. İyidir o.";
            }
            //ırk write--8. ırk --3-2-1
            if (ırka == 3 && ırkb == 2 && ırkc == 1)
            {
                label3.Text = "Altun başlıg yılan men. Altun kurugsakımın kılçın kesipen özümin yul inintin, başımın yul ebintin tir. \nAnça bilingler. Yablak ol.";
                label4.Text = "Altın başlı yılanım. Altın kursağımı kılıç ile keserek nefsimi kopar ininden, başımı kopar evinden, der. \nÖylece biliniz ki bu fal kötüdür.";
            }
            //ırk write--9. ırk --1-2-3
            if (ırka == 1 && ırkb == 2 && ırkc == 3)
            {
                label3.Text = "Ulug eb örtenmiş. Katınga tegi kalmaduk, bükinge tegi kodmaduk tir. Ança bilingler. Yablak ol";
                label4.Text = "Büyük bir ev yanmış. Katına kadar sağlam bi yeri kalmamış. \nKöşe bucağına kadar yanmadık bir yeri kalmamış der. \nÖylece biliniz ki bu fal kötüdür.";
            }
            //ırk write--10. ırk --3-4-2
            if (ırka == 3 && ırkb == 4 && ırkc == 2)
            {
                label3.Text = "Esnegen bars men. Kamuş ara başım. Antag alp men, erdemlig men. Ança bilingler. ";
                label4.Text = "Esneyip duran kaplanım.Kamışlar arasında başım. Onca cesur ve onca erdemliyim. Öylece biliniz ki bu fal iyidir.";
            }
            //ırk write--11. ırk --3-4-4
            if (ırka == 3 && ırkb == 4 && ırkc == 4)
            {
                label3.Text = "Sarıg atlıg sabçı, yazıg atlıg yalabaç edgü sab elti kelir tir. Ança biling. Edgü ol.";
                label4.Text = "Sarı atlı sözcü, yağız atlı elçi iyi haber ileterek gelir der. Böyle bilin. İyidir o.";
            }
            //ırk write--12. ırk --3-4-3
            if (ırka == 3 && ırkb == 4 && ırkc == 3)
            {
                label3.Text = "Er abka barmiş. Tagda kamılmiş. Tengride Erklig tir. Ança bilingler. Yabız ol.";
                label4.Text = "Erkek ava varmış (gitmiş). Dağda düşmüş. Gökteki kudretlidir der. Böyle biliniz. Kötüdür o";
            }
            //ırk write--13. ırk --2-4-3
            if (ırka == 2 && ırkb == 4 && ırkc == 3)
            {
                label3.Text = "Tengrilig kurtga yurtta kalmış. Yaglıg kamıç bulupan yalgayu tirilmiş, ölümde ozmiş tir. Ança bilingler.";
                label4.Text = "Dindar bir yaşlı kadın terk edilmiş bir kamp yerinde yalnız kalmış. Yağlı bir kaşık bulup yalamış. \nöylece hayatta kalmış. ölümden kurtulmuş der. öylece biliniz. ";
            }
            //ırk write--14. ırk --4-3-2
            if (ırka == 4 && ırkb == 3 && ırkc == 2)
            {
                label3.Text = "Kuzgunuk ıgaçka bamiş. Katıgdı ba, edgüti ba! tir. Ança bilingler. ";
                label4.Text = "Bir kuzgunu ağaca bağlamışlar. Sıkı bağla, iyi bağla der. öyle biliniz.";
            }
            //ırk write--15. ırk --1-4-1
            if (ırka == 1 && ırkb == 4 && ırkc == 1)
            {
                label3.Text = "üze tuman durdı, asra toz turdı,Kuş oglu uça aztı, kiyik oglu yükürü aztı, kişi oglu yorıyu aztı. \nYana Tengri kutınta üçünç yılda kop esen tükel körüşmüş. Kop ögirer sebinür tir. \nAnça bilingler. Edgü ol.";
                label4.Text = "Yukarıdan sis bastırdı, aşağıdan toz kalktı, kuş yavrusu uçup yolunu kaybetti. Bunlar yine Tanrının \nlutfu üçüncü yılda sağ salim ";
            }

            //ırk write--16. ırk --1-3-3
            if (ırka == 1 && ırkb == 3 && ırkc == 3)
            {
                label3.Text = "Toruk at semritti. Yirin öpen yügürü barmiş. Utru yirde ogrı sookuşup tutupanmiinmiş. Yilinge, \nkudursugınga tegi yagrıpan kamşayu umatın turur tir. Ança biling. Yablak ol  ";
                label4.Text = "Zayıf at semirdi. kaldığı yuvasını düşünüp koşarak gitmiş. yolda karşısına bir hırsız çıkmış. \natı tutup üstüne binmiş. At hızlı koşmaktan yelesinden kuyruğuna kadar yara bere içnde kalmış. \nkımıldıyamadan duruyor der.Böyle biliniz. Bu fal kötüdür.";
            }

            //ırk write--17. ırk --3-3-2
            if (ırka == 3 && ırkb == 3 && ırkc == 2)
            {
                label3.Text = "Özlük at öng yirde arıp onguk turu kalmis. Tengri küçnge tag üze yol sub körüpen, yiş üze yaş ot \nkörüpen, yorıyu barıpan, sub içipen, yaş yipen ölümde ozmiş tir. Ança bilingler. Edgü ol. ";
                label4.Text = "Bir binek atı çölde yorgunluktan ve susuluktan bitkin halde kala kalmış. sonra tanrının inayeti \nile dağ üstünde yol ve su görerek, dağ çayırında taze ot görerek yürüyüp gitmiş. su içip taze \notları yiyerek ölümden kurtulmuş der. Öylece biliniz ki bu fal iyidir.";
            }

            //ırk write--18. ırk --1-4-2
            if (ırka == 1 && ırkb == 4 && ırkc == 2)
            {
                label3.Text = "Keregü içi ne teg ol? Közünüki ne teg? Bar ol tir. Ança bilingler. Anyıg edgü ol. ";
                label4.Text = "Çadırın içi nasıl? Bacası nasıl? Penceresi nası? Manzaralı mı? -İyidir. İpleri Nasıl? -Var der.\nÖylece biliniz ki bu fal çok iyidir. ";
            }

            //ırk write--19. ırk --3-1-4
            if (ırka == 3 && ırkb == 1 && ırkc == 4)
            {
                label3.Text = "Ak at karşısın üç bolugta tullapan agınka ötgkeıdmiştir. Korkma, edgüri ötün. ayınma, \nedgüti yalbar! tir. Ança bilngler. Edgü ol.";
                label4.Text = "Kır at, rakibini üç arayışta seçerek bir dilsize duaya yollamış, der. \nKorkma iyi dua et. Korkma, iyi yalvar! der. Öylece bilin ki bu fal iyidirç";
            }

            //ırk write--20. ırk --3-2-2
            if (ırka == 3 && ırkb == 2 && ırkc == 2)
            {
                label3.Text = "Titir bugra men. Ürüng köpükümin saçar men. Üze tengrike tegir, asra yirke kirür tir. \nUdıgmag odguru, yatlıgıg turguru yoruyır men. Antag küçlüg men. Ança bilingler edgü ol.";
                label4.Text = "Dişi develi bir erkek deveyim. Ak köpüklerimi ağzımdan öyle saçarım ki yukarıda \ngöklere erişir, aşağıda yer dibine girer. Uyuyanları uyandırıp yatanları kaldırırım. Onca güçlüyüm. \nÖylece biliniz. Bu fal iyidir.";
            }

            //ırk write--21. ırk --1-3-3
            if (ırka == 1 && ırkb == 3 && ırkc == 3)
            {
                label3.Text = "Karı üpgüp yıl yarumazkan edi. Ödmeng, körmeng, ürkütmen(g) tir. \nAnça biling. Edgü ol.";
                label4.Text = "Yaşlı hürhüt kuşu yeni yıl sabahı daha ortalık ağarmamışken öttü. \nHeyecanlanmayın, bakmayın, ürkütmeyin der. Öylece bilin.";

            }

            //ırk write--22. ırk --2-1-1
            if (ırka == 2 && ırkb == 1 && ırkc == 1)
            {
                label3.Text = "Uzun tonlug közüngüsin kölke ıçgınmiş. Yarın yangrayur, kiçe kengrenür, tir. \nAnçabilingler. Munglug ol. anyıg yablak ol.";
                label4.Text = "Bir kadın aynasını göle düşürmüş. Bu yüzden sabahları söyleniyor, akşamları \nsızlanıyor der. Öylece biliniz. Bu fal üzücüdür. Çok kötüdür.";
            }

            //ırk write--23. ırk --2-4-4
            if (ırka == 2 && ırkb == 4 && ırkc == 4)
            {
                label3.Text = "Oglan kekük tezegin bultı.  Çekik eting, kutlug bolzun tir. \nAnça bilingler. Edgü ol.";
                label4.Text = "Bir oğlan kartal tezeğini buldu. Tarla kuşu! Etin kutlu olsun! der. \nÖylece biliniz bu fal iyidir.";

            }

            //ırk write--24. ırk --3-1-3
            if (ırka == 3 && ırkb == 1 && ırkc == 3)
            {
                label3.Text = "Tenglük kulun irkek yuntta emig tileyür. Kün ortu yüttürüp. \ntüm ortu kant, negüde bulgay ol, tir. Ança bilingler. Yabız ol.";
                label4.Text = "Kör biy tay emmek için erkek tayda meme arıyor. Güpegündüz kaybedip \ngece yarısı nerede, nasıl bulacak, der. Öylece biliniz ki bu fal kötüdür.";
            }

            //ırk write--25. ırk --1-1-3
            if (ırka == 1 && ırkb == 1 && ırkc == 3)
            {
                label3.Text = "Eki öküzüg bir bukursıka kölmiş. Kmşayu umatın turur tir. \nAnça biling. Yablak ol.";
                label4.Text = "İki öküzü bir sabana koymuşlar. Öküzler kımıldayamadan duruyor, der. \nÖylece biliniz ki. Bu fal kötüdür.";
            }

            //ırk write--26. ırk --1-2-4
            if (ırka == 1 && ırkb == 2 && ırkc == 4)
            {
                label3.Text = "Tang tanglardı, udu yir yarudı, udu kün tugdı. Kmag üze yaruk boltı tir. \nAnça biling. Edgü ol.";
                label4.Text = "Şafak söktü ve yer aydınlandı ve güneş doğdu. Herşeyin üzeri aydınlık oldu. der. \nÖylece bilin. bu fal iyidir.";
            }

            //ırk write--27. ırk --2-2-4
            if (ırka == 2 && ırkb == 2 && ırkc == 4)
            {
                label3.Text = "Bay er konyı ürküpen barmiş. Börike sookuşmiş. Böri agzı emsimiş. \nEsen tüükel bolmiş tir. Ança bilingler. Edgü ol.";
                label4.Text = "Zengin bir adamın koyunu ürküp kaçmış. Yolda bir kurda rastlamış. \nO sırada kurdun ağzı zehirlenmiş. Köyun böylece sağ kalmış, der. Öylece biliniz Bu fal iyidir. ";
            }
            //ırk write--28. ırk --1-2-0000
            if (ırka == 1 && ırkb == 2 && ırkc == 0000)
            {
                label3.Text = "Kan olurpan ordu yapmiş. İli turdmiş. Tört bulungtaki edgüsi uyurı \ntirilipen mengileyür, bedizleyür tir. Ança bilingler. Edgü ol.";
                label4.Text = "Bir han tahta oturup kendine bir saray yaptırmış. Devleti ayakta kalmış. \nÜlkesinin has ve müktedir adamlarıetrafında toplanmış, sarayını neşe içinde süslüyorlar, der. \nÖylece biliniz. Bu fal iyidir.";
            }
            //ırk write--29. ırk --2-3-4
            if (ırka == 2 && ırkb == 3 && ırkc == 4)
            {
                label3.Text = "Oyma er oglanın kisisinin tutug urupan oş iç oygalı barmiş. \nOglın kişisin utuzmaduk, yana toku on boş kony utmiş. Oglı yutuzı kop ögirer tir. Ança bilingler. Edgü ol.";
                label4.Text = "Bir sakatatçı çocuklarını ve karısını rehin olarak koyup bir \nyarışta, kesilen koyunların iç organ ve bağırsaklarını oynamaya gitmiş. Yarışta çocuklarını ve karısını kaybetmemiş, \nüstelik doksan koyun kazanmış.Çocukları ve kadını hep seviniyorlar, der. Öylece bilini bu fal iyidir.";
            }
            //ırk write--30. ırk --3-2-4
            if (ırka == 3 && ırkb == 2 && ırkc == 4)
            {
                label3.Text = "Çıgany er oglı kagançka barmiş. Yolı yaramiş. Ögire sebinü kelir tir. \nAnça bilingler. Edgü ol.";
                label4.Text = "Yoksul bir adamın oğlu para kazanmaya gitmiş. yolculuğu yararlı olmuş. \nNeşe ve sevinç içinde eve geliyor, der. Öylece biliniz. Bu fal iyidir.";
            }
            //ırk write--31. ırk --4-4-1
            if (ırka == 4 && ırkb == 4 && ırkc == 1)
            {
                label3.Text = "Bars kiyik engke mengke barmiş. Engin mengin bulmiş. \nBulupan uyasıngaru ögire sebinü kelir tir. Ança Biling. Edgü ol.";
                label4.Text = "Bir kaplan avlanmaya gitmiş. Avını bulmuş. Evine neşe ve \nsevinç içinde geliyor, der. Öylece bilin bu fal iyidir.";
            }
            //ırk write--32. ırk --4-1-1
            if (ırka == 4 && ırkb == 1 && ırkc == 1)
            {
                label3.Text = "Bir tabılku yüz boltı. Yüz tabılku ming boltı. \nMing tabılku tümen boltı tir. Ança bilingler. Asıgı bar. Edgü ol.";
                label4.Text = "Bir hünnap yüz oldu. Yüz hünnap bin bin oldu. \nBin hünnap on bin oldu, der. Öylece biliniz. Bu fal iyidir.";
            }
            //ırk write--33. ırk --4-2-4
            if (ırka == 4 && ırkb == 2 && ırkc == 4)
            {
                label3.Text = "Kidizig subka sukmiş. Takı ur, katıgdı ba tir. \nAnça bilingler. Yablak ol.";
                label4.Text = "Adamın biri keçeyi suyasokmuş. Daha çok vur, sıkıca bağla!, der. \nÖylece biliniz. Bu fal kötüdür.";
            }
            //ırk write--34. ırk --4-4-2
            if (ırka == 4 && ırkb == 4 && ırkc == 2)
            {
                label3.Text = "Kan süke barmiş. Yagıg sançmiş. Köçürü konturu kelir. \nÖzi süsi ögire sebinü ordusıngaru kelir,tir. Ança bilingler. Edgü ol.";
                label4.Text = "Bir han sefere çıkmış, düşmanı mızraklamış. Askerlerine göç ettire \nkondura geliyor. Kendisive askerleri neşe ve sevinç içinde karargahına doğru geliyor, der. Öylece biliniz. Bu fal iyidir.";
            }
            //ırk write--35. ırk --4-3-4
            if (ırka == 4 && ırkb == 3 && ırkc == 4)
            {
                label3.Text = "Er süke barmiş. Yolta atı armiş. Er kugu kuşka sokuşmiş. Kugu kuş \nkanatınga urup anı kalıyu barıpan öginge kangınga tegürmüş. Ögi kangı ögirer sebinür tir. Ança bilingler. Edgü ol";
                label4.Text = "Bir adam orduya gitmiş. Yolda atı yorulmuş. Adam bir kuğu kuşuna \nartlamış. Kuğu kuşu onu kanatlarına vurup onunla uçmuş ve anasına babasına eriştirmiş. Anası babası neşe ve sevinç içinde, der. \nÖylece biliniz. Bu fal iyidir.";
            }
            //ırk write--36. ırk --1-1-4
            if (ırka == 1 && ırkb == 1 && ırkc == 4)
            {
                label3.Text = "Üküş atlıg ögrünçüng yook, kobı atlıg korkınçıng yook, uçruglug \nkutung yookt tir. Ança ilingler. Anyıg yablak ol.";
                label4.Text = "Sende çok atı olan bir kişinin sevinci yok, sende atı az olanın \nkorkusuda yok. Sende uçuşan bayraklarla kutlanacak iyi bir talihin de yok, der. Öylece biliniz. Bu fal kötüdür.";
            }
            //ırk write--37. ırk --4-3-1
            if (ırka == 4 && ırkb == 3 && ırkc == 1)
            {
                label3.Text = "Bir karı öküzüg bilin biçe kumursga yimiş. Kamşayu umatın turur tir. \nAnça bilingler. Yablak ol.";
                label4.Text = "Yaşlı bir öküzü, bir karınca, belini biçerek yemiş. Öküz yerinden \nkımıldayamadan duruyor, der. Öylece biliniz. Bu fal kötüdür.";
            }
            //ırk write--38. ırk --4-1-3
            if (ırka == 4 && ırkb == 1 && ırkc == 3)
            {
                label3.Text = "Kamış ara kalmiş. Tengri unamaduk. Abınçu katun bolzun tir. \nAnça bilingler. Edgü ol.";
                label4.Text = "Bir köle kız kamışlar arasında kalmış. Tanrı bunu doğru \nbulmamış. Bu köle kı Hatun olsun, der. Öylece biliniz. Bu fal iyidir.";
            }
            //ırk write--39. ırk --4-2-2
            if (ırka == 4 && ırkb == 2 && ırkc == 2)
            {
                label3.Text = "Tıgıg tertü kişemiş. Kamşayu umatın turur tir. Ança bilingler. \nYablak ol.";
                label4.Text = "Demir kırı bir atın ayaklarını çapraz olarak kösteklemişler. \nAt kımıldayamadan duruyor, der. Öylece biliniz. Bu fal kötüdür.";
            }
            //ırk write--40. ırk --1-4-4
            if (ırka == 1 && ırkb == 4 && ırkc == 4)
            {
                label3.Text = "Talım urı aça yasıçin yalım kayag yara urupan yalngusun \nyorıyur tir. Antlag alp ermiş. Ança bilinglerç Edgü ol.";
                label4.Text = "Cesur bir genç, omuzları açık, okunun ucu ile yalçın kayaları \nyara yara yapayalnız yürüyor, der. Bu genç öylesine güçlü imiş. Öylece biliniz. Bu fal iyidir. ";
            }
            //ırk write--41. ırk --4-2-3
            if (ırka == 4 && ırkb == 2 && ırkc == 3)
            {
                label3.Text = "Ürüng esri inek buzagulaçı bolmiş. Ölgey men, timiş. Ürüng esri \nirkek buzagu kelürmiş. ıdukluk yaragay. Ülügde ozmiş tir. Ança biling. Edgü ol.";
                label4.Text = "Ak benekli bir inek doğurmak üzere imiş. Öleceğim, demiş. fakat \nölmemeiş, ak benekli bir erkek buzağı dünyaya getirmiş. Bunu Tanrıya kurban etmek uygun olur, böylece inek kötü talihinden \nkurtulurmuş, der. Öylece biliniz. Bu fal iyidir.";
            }
            //ırk write--42. ırk --4-1-4
            if (ırka == 4 && ırkb == 1 && ırkc == 4)
            {
                label3.Text = "Uun tonlug idişin ayakın kodupan barmiş. Yana edgüti sakınmiş.\nİdiştime ayakımta öngi kança barır men? tir. Yana kelmiş. İdişin ayakın esen tükel bulmiş. Ögirer sebinür tir.Ança bilingler.\nEdgü ol.";
                label4.Text = "Bir kadın kabını kacağını ırakıp gitmiş. Sonra iyice düşünmüş. \nKabımdan kacağımdan ayrı nereye gidiyorum ben? Demiş. Sonra yine gelmiş kabını kacağını sapasağlam bulmuş. Mutlu olup seviniyor, der. \nÖylece biliniz. Bu fal kötüdür.";
            }
            //ırk write--43. ırk --4-2-3
            if (ırka == 4 && ırkb == 2 && ırkc == 3)
            {
                label3.Text = "Togan ügüz kuşı kuşlayu barmiş. Utru talım kara kuş kopupan barmiştir. \nAnça bilingler. Edgü ol.";
                label4.Text = "Bir şahin , su kuşu avlamaya gitmiş. Yırtıcı bir kartal yerinden \nuçup karşısına çıkmış, der. Öylece biliniz. Bu fal kötüdür.";
            }
            //ırk write--44. ırk --2-4-1
            if (ırka == 2 && ırkb == 4 && ırkc == 1)
            {
                label3.Text = "Togan kuş tengriden kodı tabışgan tipen kapmiş. Togan kuş tırngakı \nsuçulunmiş yana tıtinmiş. Togan kuşung tırnakı ügüşüpen kalıyu barmiş, tabışkan terisiüngüşüpen yügürü barmiş. Antag tir.\nAnça bilingler. Yabız ol.";
                label4.Text = "Bir şahin işte bir tavşan diyerek, göklerden aşağı inmiş ve tavşanı \nyakalamak istemiş. Şahinin pençeleri yolunmuş ve sıyrılmış. Şahin penceleri yolunmuş olarak uçup  gitmiş, Tavşan derisi \nsoyulmuş olarak koşup gitmiş. Fal böyle diyor. Öylece biliniz. Bu fal kötüdür.";
            }
            //ırk write--45. ırk --2-3-1
            if (ırka == 2 && ırkb == 3 && ırkc == 1)
            {
                label3.Text = "Kiyik oglı men. Otsuz subsuz katı uyın? Neçük yorıyın? tir. \nAnça bilingler. Yabız ol.";
                label4.Text = "Geyik yavrusuyum. Otsuz ve susuz nasıl yapanilirim? Nasıl \nhayatta kalırım? der. Öylece biliniz. Bu fal kötüdür.";
            }
            //ırk write--46. ırk --3-3-1
            if (ırka == 3 && ırkb == 3 && ırkc == 1)
            {
                label3.Text = "Tebe titigke tüşmiş. Basınu yimiş. Özin tilküyimiş tir. \nAnça bilingler. Yablak ol.";
                label4.Text = "Bir deve bir bataklığa düşmüş. Bata bata yinede yemeye \ndevam etmiş. Fakat kendisinide bir tilki yemiş, der. Öylace biliniz. Bu fal kötüdür.";
            }
            //ırk write--47. ırk --4-1-1
            if (ırka == 4 && ırkb == 1 && ırkc == 1)
            {
                label3.Text = "Er ümeleyü barmis. Tengrike sookuşmiş. Kut kolmiş. Kut birmiş. \nAgılıngta yılkıng bolzun! Özüng uzun bolzun! timiş. Ança bilingler. Edgü ol.";
                label4.Text = "Adamın biri bir konukluğa gitmiş.. Yolda Tanrıya rastlamış. \nOndan şans dilemiş. Tanrıda ona şans vermiş. Ağılında atların olsun, ömrün uzun olsun! demiş. Öylece biliniz. Bu fal iyidir.";
            }

            //ırk write--48. ırk --4-4-3
            if (ırka == 4 && ırkb == 4 && ırkc == 3)
            {
                label3.Text = "Karı yol Tengri men. sınukıngın sapar men, üzükingin ulayur men. \nİlig itmiş men. Edgüsi bolzun tir. Ança bilingler. Edgü ol.";
                label4.Text = "Yaşlı yol Tanrısıyım. Senin kırıklarını onarırım, çıkıklarını \nyerine otuttururum. Nitekim ülkeyi de düzene sokmuşum. Hayırlısı olsun, der. Öylece biliniz.";
            }
            //ırk write--49. ırk --1-4-3
            if (ırka == 1 && ırkb == 4 && ırkc == 3)
            {
                label3.Text = "Bars kiyik engleyü mengleyü barmiş. Ortu yirde amgaka sokmiş. \nEsri amya yalım kayaka ünüp barmiş, ölümte özmiş. Ölümte ozupan ögire sebinü yorıyur tir. Ança biling. Edgü ol.";
                label4.Text = "Bir kaplan avlanmaya gitmiş. Orta yerde bir yaban keçisine \nrastlamış. Benekli yaban keçisi gidip yalçın bir kayaya çıkmış, ölümden kurtulmuş. Ölümden kurtulup sevinç ve neşe içinde gidiyor, \nder. Öylece bilin. Bu fal iyidir.";
            }
            //ırk write--50. ırk --3-4-1
            if (ırka == 3 && ırkb == 4 && ırkc == 1)
            {
                label3.Text = "Tig at kudrıkın tügüp tigret, yazıg kodı yadrat. \nTokuz kat üçürgüng topulgınça teritzün tir. Ança bilingler. Edgü ol.";
                label4.Text = "Demir kırı atın kuyruğunu ve onu osurtuncaya kadar \nson süratle sür. yağız atıda yıkılıp yere yıkılıncaya kadar koştur. Öyle ki dokuz kat teyeltin yırtılıp delininceye kadar terlesinler, der. \nÖylece biliniz. Bu fal kötüdür.";
            }
            //ırk write--51. ırk --3-3-4
            if (ırka == 3 && ırkb == 3 && ırkc == 4)
            {
                label3.Text = "Talım kara kuş men. Yaşıl kaya yaylagım, kızzıl kaya kışlagım ol. \nTagda turupan mengileyür men. Ança bilingler. Edgü ol.";
                label4.Text = "Yırtıcı kartalım. Yeşil kayalar yazlığım, kızııl kayalar kışlığım. \nDağlarda kaldığım için mutluyum. Öylece biliniz.";
            }
            //ırk write--52. ırk --2-1-3
            if (ırka == 2 && ırkb == 1 && ırkc == 3)
            {
                label3.Text = "Er bususlug, Tengri bulıtlıg boltı. Bulıt ara kün tugmiş, busanç \nara mengi kelmiş tir. Ança bilingler. Edgü ol.";
                label4.Text = "Adam kaygılı, gök bulutlu oldu. Bulutlar arasından güneş doğmuş, vkaygılar arasından da sevinç geliş, der. Öylece biliniz. Bu fal iyidir.";
            }
            //ırk write--53. ırk --2-3-2
            if (ırka == 2 && ırkb == 3 && ırkc == 2)
            {
                label3.Text = "Boz bulıt yorıdı, bodun üze yagdı. Kara bulıt yorıdı, kamag uze yagdı. \nTarıg bişdi, yaş ot ündi, yılkıka kişike edgü boltı tir. Ança bilingler. Edgü ol.";
                label4.Text = "Boz bulut yürüdü, halk üstüne yağmur bıraktı, kara bulut yürüdü herşeyin \nüstüne yağmur bıraktı. Ekinler olgunlaştı, taze otlar çıktı. Hayvanlar ve insanlar için iyi oldu, der. Öylece biliniz. \nBu fal iyidir.";
            }
            //ırk write--54. ırk --1-3-1
            if (ırka == 1 && ırkb == 3 && ırkc == 1)
            {
                label3.Text = "Kul sabı begingerü ötünür, kuzgun sabı Tengrigerü yalbarur. \nÜze Tengri eşidti, asra kişi bilti tir. Ança bilingler. Edgü ol.";
                label4.Text = "Kölenin sözü beyinden ricadır, kuzgunun sözü Tanrıya yakarıştır. \nBunları yukarıda Tanrı işitti, aşağıda insan bildi, der. Öylece bilin. Bu fal iyidir.";
            }
            //ırk write--55. ırk --2-1-4
            if (ırka == 2 && ırkb == 1 && ırkc == 4)
            {
                label3.Text = "Alp er oglı süke barmiş. Sü yirinte erklig sabçı törütmiş tir. \nEbingerü kelser özi atanmiş. ögrünçülüg, atı yitiglig kelir tir. Ança bilingler. Anyıg Edgü ol.";
                label4.Text = "Yiğit bir adamın oğlu savaşa gitmiş. SAvaş alanında kendine güçlü \nbir sözcük türetmiş, der. Evine doğru gelirken kendisi ünlü ve mutlu, atı da yetkin olarak geliyor, der. Öylece biliniz. \nBu fal çok iyidir.";
            }
            //ırk write--56. ırk --1-3-2
            if (ırka == 1 && ırkb == 3 && ırkc == 2)
            {
                label3.Text = "Ügringe kutlug adır men. Yagak ıgaç yaylagım, kuşlug ıgaç kışlagım. \nAnta turupan mengileyür mmen tir. Ança bilingler. Edgü ol.";
                label4.Text = "Sürüsü ile mutlu bir aygırım. Cevizlikler yazlığım, kuşlu ağaçlıklar \nkışlağım. Buralarda yaşayıp mutlu oluyorum, der. Öylece biliniz. Bu fal iyidir.";
            }
            //ırk write--57. ırk --1-2-2
            if (ırka == 4 && ırkb == 3 && ırkc == 4)
            {
                label3.Text = "Kanıgı ölmiş, köngeki tongmiş. Kangı nelük çlgey ol? Beglig ol. \nKöneki nelük tonggay? Küneşke olurur ol. Ança bilingler. Bu ırk başınta az emgeki bar. kin yana edgü bolur.";
                label4.Text = "Kızın gözde sevgilisi ölmüş, kovası da donmuş.  Gözde sevgilisi \nniçin ölsün? Beydir o. Kovası niçin donsun? Güneşte duruyor. Öylece biliniz. Bu falın başında biraz acı var, \nama sonra yine iyi olur. ";
            }
            //ırk write--58. ırk --2-2-3
            if (ırka == 2 && ırkb == 2 && ırkc == 3)
            {
                label3.Text = "Oglı öginte kangınta öbkelepen tezipen barmiş. Yana sakınmiş, \nkelmiş. Ögüm ötin alayın, kangım sabın tınglayın. tip kelmiş tir. Ança bilingler. Edgü ol. ";
                label4.Text = "Evin oğlu babasına anasına öfkelenerek kaçıp gitmiş. Sonra \nyine düşünmüş, geri gelmiş. Anamın öğüdünü alayım, babamın sözlerini dinleyim diye gelmiş, der. Öylece biliniz. \nBu fal iyidir.";
            }
            //ırk write--59. ırk --3-2-3
            if (ırka == 3 && ırkb == 2 && ırkc == 3)
            {
                label3.Text = "Yılka tegmişig yıdıtmayın, ayka tegmişik arlatmayın. edgüsi \nbolzun tir. Ança bilingler. Edgü ol.";
                label4.Text = "Bir yıla erişmişi korkutmayayım, bir aya erişmişi bozmayayım. \nHayırlısı olsun, der. Özylece biliniz. Bu fal iyidir.";
            }
            //ırk write--60. ırk --1-3-4
            if (ırka == 1 && ırkb == 3 && ırkc == 4)
            {
                label3.Text = "Tokuz arlı sıgun kiyik men. Bedük tiz üze ünüpen möngreyür men. \nÜze Tengri eidti, asra kişi bilti. Antag küçlük men tir. Ança bilingler. Edgü ol.";
                label4.Text = "Dokuz çatallı boynuzu olan erkek geyiğim. Yüksek dizlerimin üstüne \nçıkarak böğürürüm. Beni yukarıda Tanrı işitmiştir, Aşağıda insanoğlu bilmiştir. Onca güçlüyüm, der. \nÖylece biliniz. Bu fal iyidir.";
            }
            //ırk write--61. ırk --1-4-3
            if (ırka == 1 && ırkb == 4 && ırkc == 3)
            {
                label3.Text = "Turnya kuş tüşnekinge konmiş. Tuymatın tuzakka ilinmiş. \nUça umatın olurur tir. Ança bilingler. Yablak ol.";
                label4.Text = "Turna kuşu tüneğe konmuş. Farkına varmadan tuzağa takılmış, \nuçamadan oturuyor, der. Öylece biliniz. Bu fal kötüdür.";
            }
            //ırk write--62. ırk --3-1-2
            if (ırka == 3 && ırkb == 1 && ırkc == 2)
            {
                label3.Text = "Yargun kiyik men. Yaylag tagıma agıpan yaylanur turur men. \nMenglik men tir. Ança bilingler. Edgü ol.";
                label4.Text = "Yargun denilen hayvanım. Yazlık dağıma çıkarakyazı geçiriyorum. \nUtluyum, der. Öylece biliniz bu fal iyidir. ";
            }
            //ırk write--63. ırk --4-3-4
            if (ırka == 4 && ırkb == 3 && ırkc == 4)
            {
                label3.Text = "Kanlık süsi abka ünmiş. Sagır içre kiyik kirmiş. Eligin tutmiş. \nKara kamag süsi öögirer tir. Ança bilingler. Edgü ol.";
                label4.Text = "Hanın ordusu ava çıkmış. Avlak içine bir erkek karaca girmiş. \nOnu elleri ile tutmuşlar. Hanın bütün sıradan askerleri seviniyorlar, der. Öylece biliniz. Bu fal iyidir.";
            }
            //ırk write--64. ırk --1-4-3
            if (ırka == 1 && ırkb == 4 && ırkc == 3)
            {
                label3.Text = "Kök boymul toogan kuş men. Körüklüg kayaka konupan küzleyür. men, \nyagaklık togrek üze tüşüpen yaylanur men tir. Ança bilingler. Edgü ol.";
                label4.Text = "Ak boyunlu gri bir şahinim. Manzaralım kayalıklara konup etrafa \nbakınırım, üstü cevizle dolu kavak üzeine inip yazı geçiririm, der. Öylece biliniz. Bu fal iyidir.";
            }
            //ırk write--65. ırk --2-3-3
            if (ırka == 2 && ırkb == 3 && ırkc == 3)
            {
                label3.Text = "Semiz at agzı katı boltı. İdisi umaz tir. Ança bilingler. \nYablak ol.";
                label4.Text = "Semiz atın ağzı sertleşti. Sahibi onu iyileştirmek \niçin bişey yapamıyor, der. Öylece biliniz. Bu fal kötüdür.";
            }
            //ırk write--66. ırk --Hatime -1-2-1(Kolofon)
            if (ırka == 1 && ırkb == 2 && ırkc == 1)
            {
                label3.Text = "Amtı amrak oglanın, ança bilingler. Bu ırk bitig edgü ol. \nAnçıp alku kentü ülügi erlik ol.";
                label4.Text = "Şimdi, sevgili çocuğum, şöylece biliniz. Bu fal kitabı iyidir. \nFakat, yinede herkes kendi kaderi üzerinde güç sahibidir. ";
            }
            //ırk write--67. ırk 4-3-3
            if (ırka == 4 && ırkb == 3 && ırkc == 3)
            {
                label3.Text = "Bars yıl, ekinti ay, bir yigirmike Tay-gün-tan manıstantakı kiçig \ndintar burua guru eşidip içimiz isig Sangun itaçuk bitidim.";
                label4.Text = "Kaplan yılında, ikinci ayın onbeşinde, Taygündan manastırında, \nben genç dindar mürit, Mürşit KAHİN'den, işitip ağabeyimiz AZİZ SANGUN İTAÇUK için bu kitabı yazdım.";
            }



        }

    }
}
